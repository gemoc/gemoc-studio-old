
        // Automatically generated file. Do not edit.

        public interface ProjectBuild {
            public static final String VERSION = "1.0";
            public static final String BUILD_NUMBER = "99";
        }
        