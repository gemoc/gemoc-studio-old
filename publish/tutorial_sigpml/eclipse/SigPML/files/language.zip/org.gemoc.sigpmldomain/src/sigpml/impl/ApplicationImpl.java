/**
 */
package sigpml.impl;

import java.util.Collection;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.util.EObjectContainmentWithInverseEList;
import org.eclipse.emf.ecore.util.InternalEList;
import sigpml.Application;
import sigpml.Block;
import sigpml.Connector;
import sigpml.SigpmlPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Application</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link sigpml.impl.ApplicationImpl#getOwnedBlocks <em>Owned Blocks</em>}</li>
 *   <li>{@link sigpml.impl.ApplicationImpl#getOwnedConnectors <em>Owned Connectors</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class ApplicationImpl extends NamedElementImpl implements Application {
	/**
	 * The cached value of the '{@link #getOwnedBlocks() <em>Owned Blocks</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOwnedBlocks()
	 * @generated
	 * @ordered
	 */
	protected EList<Block> ownedBlocks;

	/**
	 * The cached value of the '{@link #getOwnedConnectors() <em>Owned Connectors</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOwnedConnectors()
	 * @generated
	 * @ordered
	 */
	protected EList<Connector> ownedConnectors;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ApplicationImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SigpmlPackage.Literals.APPLICATION;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Block> getOwnedBlocks() {
		if (ownedBlocks == null) {
			ownedBlocks = new EObjectContainmentWithInverseEList<Block>(Block.class, this, SigpmlPackage.APPLICATION__OWNED_BLOCKS, SigpmlPackage.BLOCK__OWNER);
		}
		return ownedBlocks;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Connector> getOwnedConnectors() {
		if (ownedConnectors == null) {
			ownedConnectors = new EObjectContainmentWithInverseEList<Connector>(Connector.class, this, SigpmlPackage.APPLICATION__OWNED_CONNECTORS, SigpmlPackage.CONNECTOR__OWNER);
		}
		return ownedConnectors;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case SigpmlPackage.APPLICATION__OWNED_BLOCKS:
				return ((InternalEList<InternalEObject>)(InternalEList<?>)getOwnedBlocks()).basicAdd(otherEnd, msgs);
			case SigpmlPackage.APPLICATION__OWNED_CONNECTORS:
				return ((InternalEList<InternalEObject>)(InternalEList<?>)getOwnedConnectors()).basicAdd(otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case SigpmlPackage.APPLICATION__OWNED_BLOCKS:
				return ((InternalEList<?>)getOwnedBlocks()).basicRemove(otherEnd, msgs);
			case SigpmlPackage.APPLICATION__OWNED_CONNECTORS:
				return ((InternalEList<?>)getOwnedConnectors()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case SigpmlPackage.APPLICATION__OWNED_BLOCKS:
				return getOwnedBlocks();
			case SigpmlPackage.APPLICATION__OWNED_CONNECTORS:
				return getOwnedConnectors();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case SigpmlPackage.APPLICATION__OWNED_BLOCKS:
				getOwnedBlocks().clear();
				getOwnedBlocks().addAll((Collection<? extends Block>)newValue);
				return;
			case SigpmlPackage.APPLICATION__OWNED_CONNECTORS:
				getOwnedConnectors().clear();
				getOwnedConnectors().addAll((Collection<? extends Connector>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case SigpmlPackage.APPLICATION__OWNED_BLOCKS:
				getOwnedBlocks().clear();
				return;
			case SigpmlPackage.APPLICATION__OWNED_CONNECTORS:
				getOwnedConnectors().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case SigpmlPackage.APPLICATION__OWNED_BLOCKS:
				return ownedBlocks != null && !ownedBlocks.isEmpty();
			case SigpmlPackage.APPLICATION__OWNED_CONNECTORS:
				return ownedConnectors != null && !ownedConnectors.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //ApplicationImpl
