/**
 */
package sigpml;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Output Port</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see sigpml.SigpmlPackage#getOutputPort()
 * @model
 * @generated
 */
public interface OutputPort extends Port {
} // OutputPort
