/**
 */
package sigpml;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Application</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link sigpml.Application#getOwnedBlocks <em>Owned Blocks</em>}</li>
 *   <li>{@link sigpml.Application#getOwnedConnectors <em>Owned Connectors</em>}</li>
 * </ul>
 * </p>
 *
 * @see sigpml.SigpmlPackage#getApplication()
 * @model
 * @generated
 */
public interface Application extends NamedElement {
	/**
	 * Returns the value of the '<em><b>Owned Blocks</b></em>' containment reference list.
	 * The list contents are of type {@link sigpml.Block}.
	 * It is bidirectional and its opposite is '{@link sigpml.Block#getOwner <em>Owner</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Owned Blocks</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Owned Blocks</em>' containment reference list.
	 * @see sigpml.SigpmlPackage#getApplication_OwnedBlocks()
	 * @see sigpml.Block#getOwner
	 * @model opposite="owner" containment="true"
	 * @generated
	 */
	EList<Block> getOwnedBlocks();

	/**
	 * Returns the value of the '<em><b>Owned Connectors</b></em>' containment reference list.
	 * The list contents are of type {@link sigpml.Connector}.
	 * It is bidirectional and its opposite is '{@link sigpml.Connector#getOwner <em>Owner</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Owned Connectors</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Owned Connectors</em>' containment reference list.
	 * @see sigpml.SigpmlPackage#getApplication_OwnedConnectors()
	 * @see sigpml.Connector#getOwner
	 * @model opposite="owner" containment="true"
	 * @generated
	 */
	EList<Connector> getOwnedConnectors();

} // Application
