/**
 */
package sigpml.tests;

import junit.framework.Test;
import junit.framework.TestSuite;

import junit.textui.TestRunner;

/**
 * <!-- begin-user-doc -->
 * A test suite for the '<em><b>Sigpmldomain</b></em>' model.
 * <!-- end-user-doc -->
 * @generated
 */
public class SigpmldomainAllTests extends TestSuite {

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(suite());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static Test suite() {
		TestSuite suite = new SigpmldomainAllTests("Sigpmldomain Tests");
		suite.addTest(SigpmlTests.suite());
		return suite;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SigpmldomainAllTests(String name) {
		super(name);
	}

} //SigpmldomainAllTests
