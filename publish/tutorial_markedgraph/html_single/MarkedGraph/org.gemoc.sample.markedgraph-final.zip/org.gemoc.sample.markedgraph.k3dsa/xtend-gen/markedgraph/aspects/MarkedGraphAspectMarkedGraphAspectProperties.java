package markedgraph.aspects;

@SuppressWarnings("all")
public class MarkedGraphAspectMarkedGraphAspectProperties {
}
