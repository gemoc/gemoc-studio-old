package markedgraph.aspects;

@SuppressWarnings("all")
public class TransitionAspectTransitionAspectProperties {
}
