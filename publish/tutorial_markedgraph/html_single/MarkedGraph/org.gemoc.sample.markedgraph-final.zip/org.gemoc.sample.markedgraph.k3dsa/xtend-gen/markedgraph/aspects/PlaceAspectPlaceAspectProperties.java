package markedgraph.aspects;

@SuppressWarnings("all")
public class PlaceAspectPlaceAspectProperties {
  public int runtimeTokenCount;
}
