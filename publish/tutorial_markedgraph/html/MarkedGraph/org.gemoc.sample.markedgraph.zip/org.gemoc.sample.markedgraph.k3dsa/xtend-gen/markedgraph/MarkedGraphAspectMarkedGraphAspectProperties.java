package markedgraph;

@SuppressWarnings("all")
public class MarkedGraphAspectMarkedGraphAspectProperties {
}
