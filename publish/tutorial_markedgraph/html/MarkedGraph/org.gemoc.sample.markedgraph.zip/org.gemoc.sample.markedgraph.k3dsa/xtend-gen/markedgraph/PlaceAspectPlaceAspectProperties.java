package markedgraph;

@SuppressWarnings("all")
public class PlaceAspectPlaceAspectProperties {
  public int runtimeTokenCount;
}
