package markedgraph;

import java.util.Map;
import markedgraph.MarkedGraph;
import markedgraph.MarkedGraphAspectMarkedGraphAspectProperties;

@SuppressWarnings("all")
public class MarkedGraphAspectMarkedGraphAspectContext {
  public final static MarkedGraphAspectMarkedGraphAspectContext INSTANCE = new MarkedGraphAspectMarkedGraphAspectContext();
  
  public static MarkedGraphAspectMarkedGraphAspectProperties getSelf(final MarkedGraph _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new markedgraph.MarkedGraphAspectMarkedGraphAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<MarkedGraph, MarkedGraphAspectMarkedGraphAspectProperties> map = new java.util.WeakHashMap<markedgraph.MarkedGraph, markedgraph.MarkedGraphAspectMarkedGraphAspectProperties>();
  
  public Map<MarkedGraph, MarkedGraphAspectMarkedGraphAspectProperties> getMap() {
    return map;
  }
}
