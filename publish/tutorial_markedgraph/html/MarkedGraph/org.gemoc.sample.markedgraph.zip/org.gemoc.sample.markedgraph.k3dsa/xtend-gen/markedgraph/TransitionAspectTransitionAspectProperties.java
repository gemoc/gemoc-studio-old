package markedgraph;

@SuppressWarnings("all")
public class TransitionAspectTransitionAspectProperties {
}
